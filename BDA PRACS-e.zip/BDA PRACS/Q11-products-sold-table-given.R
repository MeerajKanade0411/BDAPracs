bread <- c(12, 3, 5, 11, 9)
milk <- c(21, 27, 18, 20, 15)
cola <- c(10, 1, 33, 6, 12)
chocolate <- c(6, 7, 4, 13, 12)
detergent <- c(5, 8, 12, 20, 23)

# Data subset operators in R: [ ], subset()
print(bread)