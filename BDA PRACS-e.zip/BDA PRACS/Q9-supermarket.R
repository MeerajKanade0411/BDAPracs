# Sample Supermarket data
supermarket <- data.frame(Product=c("Bread", "Milk", "Cola", "Chocolate", "Detergent"), Monday=c(12,21,10,6,5), Tuesday=c(3,27,1,7,8))
barplot(as.matrix(supermarket[,-1]), beside=TRUE, col=rainbow(5), main="Supermarket Data Analysis")
